curl -o release.zip https://raw.githubusercontent.com/ERCdEX/automation-toolkit/master/release.zip
unzip -j ./release.zip release/* -d .
