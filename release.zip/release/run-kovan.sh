sh ./check-path.sh
ETHEREUM_CHAIN=kovan docker-compose up --build
