sh ./check-path.sh
ETHEREUM_CHAIN=kovan SYNC_BLOCK=6500000 docker-compose up --build
