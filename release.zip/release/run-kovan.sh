sh ./check-path.sh
ETHEREUM_CHAIN=kovan SYNC_BLOCK=7391032 docker-compose up --build
