sh ./check-path.sh
ETHEREUM_CHAIN=foundation SYNC_BLOCK=5648285 docker-compose up --build
