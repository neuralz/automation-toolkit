sh ./check-path.sh
ETHEREUM_CHAIN=foundation docker-compose up --build
